package com.cg.repo;

import java.util.Optional;

import com.cg.beans.Account;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Optional<Account> findByUsername(String username);
}