package com.cg.repo;

import java.util.Collection;

import com.cg.beans.Bookmark;

public interface BookmarkRepository extends JpaRepository<Bookmark, Long> {
    Collection<Bookmark> findByAccountUsername(String username);
}