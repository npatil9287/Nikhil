package com.capgemini;

import org.springframework.stereotype.Component;

@Component
public class Employee {
	
	private int employeeId;
	private String name;
	private Adress address;
	public Employee()
	{
		System.out.println("from employee constructor");
	}
	
	public Employee(int employeeId,String name){
		this.employeeId=employeeId;
		this.name=name;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Adress getAddress() {
		return address;
	}

	public void setAddress(Adress address) {
		this.address = address;
	}
	
	
	

}
