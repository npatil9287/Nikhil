package com.capgemini;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//Employee employee = (Employee)applicationContext.getBean("employee");
		System.out.println("After application context container");
		  Employee employee = applicationContext.getBean("employee", Employee.class);
		  Adress address = applicationContext.getBean("idAddress", Adress.class);
		  Adress address2 = applicationContext.getBean("idAddress", Adress.class);
		  address.setCity("Pune");
		  address2.setCity("Pune2");
		  employee.setEmployeeId(100);
		  employee.setName("testname");
		  employee.setAddress(address);
		  System.out.println(employee.getEmployeeId());
		  System.out.println(employee.getName());
		  System.out.println(employee.getAddress().getCity());
		  
//		  Employee employee1 = applicationContext.getBean("employee", Employee.class);

		
	
	}

}
