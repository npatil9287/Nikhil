package com.capgemini;

public class Adress {

	private String city;
	
	public Adress(){
		System.out.println("from address constructor");
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
}
